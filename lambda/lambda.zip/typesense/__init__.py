from .client import Client  # NOQA
import logging

logging.basicConfig(level=logging.WARN)
